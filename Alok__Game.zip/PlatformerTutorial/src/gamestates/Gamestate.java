package gamestates;

public enum Gamestate {

	PLAYING, MENU, OPTIONS, QUIT, CREDITS;

	public static Gamestate state = MENU;

}
